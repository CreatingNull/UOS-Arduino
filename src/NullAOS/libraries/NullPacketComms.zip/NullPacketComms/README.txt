NullPacketComms Arduino Library
Steve Richardson (Creating Null)

This lib was distributed as part of the UOS system see: https://github.com/CreatingNull/UART-Arduino-Operating-System

For information on installing libraries see: https://www.arduino.cc/en/Guide/Libraries
