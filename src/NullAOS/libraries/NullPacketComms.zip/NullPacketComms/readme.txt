Author: Steve Richardson
Code Name: NullPacketComms Arduino Library
Version: 1.0.0

For information on installing libraries, see: http://www.arduino.cc/en/Guide/Libraries
